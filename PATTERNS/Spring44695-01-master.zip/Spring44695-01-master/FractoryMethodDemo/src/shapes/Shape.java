/**
 * 
 */
package shapes;

/**
 * @author ajay
 *
 */
public interface Shape {
	public abstract double area();
	public abstract double perimeter();
}
