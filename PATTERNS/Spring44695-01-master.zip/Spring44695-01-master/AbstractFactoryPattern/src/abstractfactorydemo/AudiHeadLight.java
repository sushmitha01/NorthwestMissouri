package abstractfactorydemo;


public class AudiHeadLight implements HeadLight {

	@Override
	public String getHeadLightModel() {
		return "Audi HeadLight";
	}

}
