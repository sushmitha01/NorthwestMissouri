package abstractfactorydemo;

public interface HeadLight {

	String getHeadLightModel();
}
