package abstractfactorydemo;

public interface Tire {

	String getTireModel();
}
