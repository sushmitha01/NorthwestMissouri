package abstractfactorydemo;


public class AudiTire implements Tire {

	@Override
	public String getTireModel() {
		return "Audi Tire";
	}

}
