package abstractfactorydemo;

public class MercedesTire implements Tire {

	@Override
	public String getTireModel() {
		return "Mercedes Tire";
	}

}
