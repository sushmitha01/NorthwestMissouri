package abstractfactorydemo;

public class MercedesHeadLight implements HeadLight {

	@Override
	public String getHeadLightModel() {
		return "Mercedes HeadLight";
	}

}
